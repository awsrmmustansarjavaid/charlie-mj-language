; Charlie MJ Language - Windows installer (NSIS, Unicode)
; Installs to C:\Program Files (x86)\Charlie MJ Language\ (requires Administrator)
Unicode true
!include "MUI2.nsh"
!include "nsDialogs.nsh"
!include "LogicLib.nsh"
!include "FileFunc.nsh"
!insertmacro GetSize

!define APPNAME   "Charlie MJ Language"
!define APPVER    "2.1.0"
!define UNINSTKEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\CharlieMJLanguage"

Name "${APPNAME}"
OutFile "..\dist\charlie-mj-language-installer.exe"
InstallDir "$PROGRAMFILES32\${APPNAME}"
RequestExecutionLevel admin
SetCompressor /SOLID lzma
BrandingText "${APPNAME} ${APPVER}"
Icon "..\assets\charlie-mj.ico"
UninstallIcon "..\assets\charlie-mj.ico"

VIProductVersion "2.1.0.0"
VIAddVersionKey "ProductName" "${APPNAME}"
VIAddVersionKey "FileDescription" "${APPNAME} Installer"
VIAddVersionKey "CompanyName" "Charlie MJ"
VIAddVersionKey "FileVersion" "2.1.0.0"
VIAddVersionKey "ProductVersion" "2.1.0.0"
VIAddVersionKey "LegalCopyright" "Charlie MJ"

!define MUI_ICON   "..\assets\charlie-mj.ico"
!define MUI_UNICON "..\assets\charlie-mj.ico"
!define MUI_ABORTWARNING
!define MUI_WELCOMEFINISHPAGE_BITMAP "..\assets\welcome.bmp"
!define MUI_UNWELCOMEFINISHPAGE_BITMAP "..\assets\welcome.bmp"
!define MUI_HEADERIMAGE
!define MUI_HEADERIMAGE_BITMAP "..\assets\header.bmp"
!define MUI_HEADERIMAGE_RIGHT

!define MUI_WELCOMEPAGE_TITLE "Welcome to ${APPNAME} ${APPVER}"
!define MUI_WELCOMEPAGE_TEXT "This wizard installs ${APPNAME} into:$\r$\n$\r$\n$PROGRAMFILES32\${APPNAME}$\r$\n$\r$\nand lets you choose which Google Chrome profile to use.$\r$\n$\r$\nClick Next to continue."

!define MUI_FINISHPAGE_TITLE "${APPNAME} is installed"
!define MUI_FINISHPAGE_TEXT "Final step - add the extension to your selected Chrome profile:$\r$\n$\r$\n1. Turn on 'Developer mode' (top-right of the Extensions page).$\r$\n2. Click 'Load unpacked'.$\r$\n3. Paste the folder path (already copied to your clipboard) and click 'Select Folder'.$\r$\n$\r$\nChrome does not allow a normal installer to add an extension into a profile on its own, so this one step is done by you."
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_TEXT "Open Chrome Extensions page now (copies the folder path)"
!define MUI_FINISHPAGE_RUN_FUNCTION LaunchSetup
!define MUI_FINISHPAGE_NOREBOOTSUPPORT

Var Dlg
Var Combo
Var ProfileDir

!insertmacro MUI_PAGE_WELCOME
Page custom ProfilePageCreate ProfilePageLeave
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

Function .onInit
  SetShellVarContext all
FunctionEnd

Function un.onInit
  SetShellVarContext all
FunctionEnd

Function ProfilePageCreate
  !insertmacro MUI_HEADER_TEXT "Choose Chrome profile" "Select the Google Chrome profile where you will use ${APPNAME}."
  InitPluginsDir
  File "/oname=$PLUGINSDIR\Detect-ChromeProfiles.ps1" "..\scripts\Detect-ChromeProfiles.ps1"
  Delete "$PLUGINSDIR\profiles.txt"
  nsExec::Exec 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "$PLUGINSDIR\Detect-ChromeProfiles.ps1" -Out "$PLUGINSDIR\profiles.txt"'
  Pop $0

  nsDialogs::Create 1018
  Pop $Dlg
  ${If} $Dlg == error
    Abort
  ${EndIf}

  ${NSD_CreateLabel} 0 0 100% 24u "Pick the Chrome profile (for example your personal or work account). The extension folder will be opened in that profile at the end of setup."
  Pop $0
  ${NSD_CreateLabel} 0 34u 100% 10u "Chrome profile:"
  Pop $0
  ${NSD_CreateDropList} 0 46u 100% 100u ""
  Pop $Combo

  StrCpy $1 0
  ${If} ${FileExists} "$PLUGINSDIR\profiles.txt"
    FileOpen $2 "$PLUGINSDIR\profiles.txt" r
    ${Do}
      FileRead $2 $3
      ${If} ${Errors}
        ${Break}
      ${EndIf}
      ${Do}
        StrCpy $4 $3 1 -1
        ${If} $4 == "$\r"
        ${OrIf} $4 == "$\n"
          StrCpy $3 $3 -1
        ${Else}
          ${Break}
        ${EndIf}
      ${Loop}
      ${If} $3 != ""
        SendMessage $Combo ${CB_ADDSTRING} 0 "STR:$3"
        IntOp $1 $1 + 1
      ${EndIf}
    ${Loop}
    FileClose $2
  ${EndIf}

  ${If} $1 = 0
    SendMessage $Combo ${CB_ADDSTRING} 0 "STR:Default profile  [Default]"
    ${NSD_CreateLabel} 0 70u 100% 20u "No Chrome profiles were detected. Chrome's Default profile will be used. You can run this installer again later to change it."
    Pop $0
  ${EndIf}
  SendMessage $Combo ${CB_SETCURSEL} 0 0

  ${If} ${FileExists} "$PROGRAMFILES64\Google\Chrome\Application\chrome.exe"
  ${OrIf} ${FileExists} "$PROGRAMFILES32\Google\Chrome\Application\chrome.exe"
  ${OrIf} ${FileExists} "$LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
  ${Else}
    ${NSD_CreateLabel} 0 100u 100% 20u "Warning: Google Chrome was not detected on this PC. You can still install now and add the extension after installing Chrome."
    Pop $0
  ${EndIf}
  nsDialogs::Show
FunctionEnd

; Profile directory name = text between the last [ and the final ]
Function ProfilePageLeave
  ${NSD_GetText} $Combo $0
  StrCpy $ProfileDir "Default"
  StrLen $1 $0
  ${If} $1 > 2
    IntOp $2 $1 - 1
    ${Do}
      StrCpy $3 $0 1 $2
      ${If} $3 == "["
        IntOp $4 $1 - $2
        IntOp $4 $4 - 2
        IntOp $2 $2 + 1
        StrCpy $5 $0 $4 $2
        ${If} $5 != ""
          StrCpy $ProfileDir $5
        ${EndIf}
        ${Break}
      ${EndIf}
      IntOp $2 $2 - 1
    ${LoopUntil} $2 < 0
  ${EndIf}
FunctionEnd

Section "Install"
  SetShellVarContext all

  ; --- Offer to remove the old per-user install (AppData) from earlier versions ---
  ${If} ${FileExists} "$LOCALAPPDATA\${APPNAME}\charlie-mj-language.exe"
    MessageBox MB_YESNO|MB_ICONQUESTION "An older per-user install was found in:$\r$\n$LOCALAPPDATA\${APPNAME}$\r$\n$\r$\nRemove it?$\r$\n$\r$\n(Chrome will treat the new Program Files copy as a new extension. Remove the old extension in chrome://extensions and load the new one. Data saved inside the old extension does not transfer.)" /SD IDNO IDNO skip_old
    SetShellVarContext current
    Delete "$DESKTOP\${APPNAME}.lnk"
    RMDir /r "$SMPROGRAMS\${APPNAME}"
    SetShellVarContext all
    RMDir /r "$LOCALAPPDATA\${APPNAME}"
    DeleteRegKey HKCU "${UNINSTKEY}"
    skip_old:
  ${EndIf}

  SetOutPath "$INSTDIR"
  RMDir /r "$INSTDIR\extension"
  File "..\dist\charlie-mj-language.exe"
  WriteINIStr "$INSTDIR\config.ini" "Settings" "Profile" "$ProfileDir"

  SetOutPath "$INSTDIR\assets"
  File "/oname=charlie-mj-language.ico" "..\assets\charlie-mj.ico"

  SetOutPath "$INSTDIR\extension"
  File /r "..\extension\*.*"

  SetOutPath "$INSTDIR"
  CreateDirectory "$SMPROGRAMS\${APPNAME}"
  CreateShortcut "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk" "$INSTDIR\charlie-mj-language.exe" "" "$INSTDIR\assets\charlie-mj-language.ico"
  CreateShortcut "$SMPROGRAMS\${APPNAME}\Add extension to Chrome.lnk" "$INSTDIR\charlie-mj-language.exe" "--setup" "$INSTDIR\assets\charlie-mj-language.ico"
  CreateShortcut "$SMPROGRAMS\${APPNAME}\Uninstall ${APPNAME}.lnk" "$INSTDIR\Uninstall.exe"
  CreateShortcut "$DESKTOP\${APPNAME}.lnk" "$INSTDIR\charlie-mj-language.exe" "" "$INSTDIR\assets\charlie-mj-language.ico"

  WriteUninstaller "$INSTDIR\Uninstall.exe"
  WriteRegStr HKLM "${UNINSTKEY}" "DisplayName" "${APPNAME}"
  WriteRegStr HKLM "${UNINSTKEY}" "DisplayVersion" "${APPVER}"
  WriteRegStr HKLM "${UNINSTKEY}" "Publisher" "Charlie MJ"
  WriteRegStr HKLM "${UNINSTKEY}" "DisplayIcon" "$INSTDIR\assets\charlie-mj-language.ico"
  WriteRegStr HKLM "${UNINSTKEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKLM "${UNINSTKEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegDWORD HKLM "${UNINSTKEY}" "NoModify" 1
  WriteRegDWORD HKLM "${UNINSTKEY}" "NoRepair" 1
  ${GetSize} "$INSTDIR" "/S=0K" $0 $1 $2
  IntFmt $0 "0x%08X" $0
  WriteRegDWORD HKLM "${UNINSTKEY}" "EstimatedSize" "$0"
SectionEnd

; The installer runs as Administrator. Chrome must NOT be started elevated, so the
; "Add extension to Chrome" shortcut is opened through Explorer, which runs it as the normal user.
Function LaunchSetup
  Exec '"$WINDIR\explorer.exe" "$SMPROGRAMS\${APPNAME}\Add extension to Chrome.lnk"'
FunctionEnd

Section "Uninstall"
  SetShellVarContext all
  Delete "$DESKTOP\${APPNAME}.lnk"
  RMDir /r "$SMPROGRAMS\${APPNAME}"
  RMDir /r "$INSTDIR\extension"
  RMDir /r "$INSTDIR\assets"
  Delete "$INSTDIR\charlie-mj-language.exe"
  Delete "$INSTDIR\config.ini"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR"
  DeleteRegKey HKLM "${UNINSTKEY}"
SectionEnd
