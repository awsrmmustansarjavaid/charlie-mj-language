param([string]$Out)
# Lists Google Chrome profiles as lines:  "Profile name (email)  [DirectoryName]"
$ud = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data'
$ls = Join-Path $ud 'Local State'
$lines = @()
try {
  if (Test-Path $ls) {
    $j = Get-Content $ls -Raw -Encoding UTF8 | ConvertFrom-Json
    $ic = $j.profile.info_cache
    if ($ic) {
      $items = foreach ($p in $ic.PSObject.Properties) {
        $name = [string]$p.Value.name
        if (-not $name) { $name = $p.Name }
        $mail = [string]$p.Value.user_name
        if ($mail) { $name = "$name ($mail)" }
        [pscustomobject]@{ Dir = $p.Name; Label = "$name  [$($p.Name)]" }
      }
      $lines = @($items | Sort-Object @{Expression={ if ($_.Dir -eq 'Default') {0} else {1} }}, Dir | ForEach-Object { $_.Label })
    }
  }
} catch { }
if (-not $lines -and (Test-Path (Join-Path $ud 'Default'))) { $lines = @('Default  [Default]') }
[IO.File]::WriteAllLines($Out, [string[]]$lines, [Text.Encoding]::Default)
