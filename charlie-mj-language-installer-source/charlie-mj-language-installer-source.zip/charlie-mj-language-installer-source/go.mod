module charliemj/installer

go 1.24
