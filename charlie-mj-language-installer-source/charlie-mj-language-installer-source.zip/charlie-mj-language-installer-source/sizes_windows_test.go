//go:build windows

package main

import (
	"testing"
	"unsafe"
)

func TestStructSizes(t *testing.T) {
	if unsafe.Sizeof(ncMetrics{}) != 504 || unsafe.Sizeof(logFont{}) != 92 || unsafe.Sizeof(wndClassEx{}) != 80 || unsafe.Sizeof(browseInfo{}) != 64 || unsafe.Sizeof(winMsg{}) != 48 {
		t.Fatal(unsafe.Sizeof(ncMetrics{}), unsafe.Sizeof(logFont{}), unsafe.Sizeof(wndClassEx{}), unsafe.Sizeof(browseInfo{}), unsafe.Sizeof(winMsg{}))
	}
}
