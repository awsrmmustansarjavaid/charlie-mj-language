//go:build !windows

package main

import (
	"fmt"
	"os"
)

// The installer UI is Windows only. This stub lets the package build and the
// core logic be unit tested on other platforms.
func runInstaller() {
	fmt.Fprintln(os.Stderr, "charlie-mj-language-installer is a Windows program.")
	os.Exit(1)
}
func runUninstaller() { runInstaller() }
