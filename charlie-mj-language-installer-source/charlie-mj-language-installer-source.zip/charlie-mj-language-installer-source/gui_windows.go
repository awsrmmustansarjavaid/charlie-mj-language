//go:build windows

package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"unicode/utf16"
	"unsafe"
)

// ------------------------------------------------------------ Win32 glue

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	ole32    = syscall.NewLazyDLL("ole32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	advapi32 = syscall.NewLazyDLL("advapi32.dll")

	pRegSetValueEx = advapi32.NewProc("RegSetValueExW")
	pRegDeleteKey  = advapi32.NewProc("RegDeleteKeyW")
	pRegCreateKey  = advapi32.NewProc("RegCreateKeyExW")
	pRegOpenKey    = advapi32.NewProc("RegOpenKeyExW")
	pRegQueryValue = advapi32.NewProc("RegQueryValueExW")
	pRegCloseKey   = advapi32.NewProc("RegCloseKey")

	pRegisterClassEx   = user32.NewProc("RegisterClassExW")
	pCreateWindowEx    = user32.NewProc("CreateWindowExW")
	pDefWindowProc     = user32.NewProc("DefWindowProcW")
	pGetMessage        = user32.NewProc("GetMessageW")
	pTranslateMessage  = user32.NewProc("TranslateMessage")
	pDispatchMessage   = user32.NewProc("DispatchMessageW")
	pIsDialogMessage   = user32.NewProc("IsDialogMessageW")
	pPostQuitMessage   = user32.NewProc("PostQuitMessage")
	pDestroyWindow     = user32.NewProc("DestroyWindow")
	pShowWindow        = user32.NewProc("ShowWindow")
	pSendMessage       = user32.NewProc("SendMessageW")
	pSetWindowText     = user32.NewProc("SetWindowTextW")
	pGetWindowText     = user32.NewProc("GetWindowTextW")
	pGetWindowTextLen  = user32.NewProc("GetWindowTextLengthW")
	pEnableWindow      = user32.NewProc("EnableWindow")
	pMessageBox        = user32.NewProc("MessageBoxW")
	pLoadCursor        = user32.NewProc("LoadCursorW")
	pLoadImage         = user32.NewProc("LoadImageW")
	pAdjustWindowRect  = user32.NewProc("AdjustWindowRectEx")
	pGetSystemMetrics  = user32.NewProc("GetSystemMetrics")
	pSetForegroundWin  = user32.NewProc("SetForegroundWindow")
	pGetDpiForSystem   = user32.NewProc("GetDpiForSystem")
	pSystemParamInfo   = user32.NewProc("SystemParametersInfoW")
	pOpenClipboard     = user32.NewProc("OpenClipboard")
	pCloseClipboard    = user32.NewProc("CloseClipboard")
	pEmptyClipboard    = user32.NewProc("EmptyClipboard")
	pSetClipboardData  = user32.NewProc("SetClipboardData")
	pGetModuleHandle   = kernel32.NewProc("GetModuleHandleW")
	pGlobalAlloc       = kernel32.NewProc("GlobalAlloc")
	pGlobalLock        = kernel32.NewProc("GlobalLock")
	pGlobalUnlock      = kernel32.NewProc("GlobalUnlock")
	pSHBrowseForFolder = shell32.NewProc("SHBrowseForFolderW")
	pSHGetPathFromID   = shell32.NewProc("SHGetPathFromIDListW")
	pCoInitializeEx    = ole32.NewProc("CoInitializeEx")
	pCoTaskMemFree     = ole32.NewProc("CoTaskMemFree")
	pCreateFontIndirec = gdi32.NewProc("CreateFontIndirectW")
	pGetStockObject    = gdi32.NewProc("GetStockObject")
)

const (
	wsCaption     = 0x00C00000
	wsSysMenu     = 0x00080000
	wsMinimizeBox = 0x00020000
	wsChild       = 0x40000000
	wsVisible     = 0x10000000
	wsTabStop     = 0x00010000
	wsBorder      = 0x00800000
	wsGroup       = 0x00020000

	wmDestroy = 0x0002
	wmClose   = 0x0010
	wmCommand = 0x0111
	wmSetFont = 0x0030
	wmSetIcon = 0x0080

	bmGetCheck = 0x00F0
	bmSetCheck = 0x00F1
	cbAddStr   = 0x0143
	cbGetCur   = 0x0147
	cbSetCur   = 0x014E
	stmSetIcon = 0x0170

	ssIcon        = 0x03
	ssNoPrefix    = 0x80
	ssEtchedHorz  = 0x10
	bsDefPush     = 0x01
	bsAutoCheck   = 0x03
	esAutoHScroll = 0x80
	cbsDropList   = 0x03

	mbOK          = 0x0
	mbYesNo       = 0x4
	mbIconInfo    = 0x40
	mbIconWarning = 0x30
	mbIconError   = 0x10
	idYes         = 6

	idPath    = 101
	idBrowse  = 102
	idProfile = 103
	idCheck   = 104
	idInstall = 105
	idClose   = 106
	idNote    = 107
	idVersion = 108
	idProfLbl = 109

	iconResID = 1 // RT_GROUP_ICON id written by tools/make_syso.py
)

type wndClassEx struct {
	cbSize        uint32
	style         uint32
	lpfnWndProc   uintptr
	cbClsExtra    int32
	cbWndExtra    int32
	hInstance     uintptr
	hIcon         uintptr
	hCursor       uintptr
	hbrBackground uintptr
	lpszMenuName  *uint16
	lpszClassName *uint16
	hIconSm       uintptr
}

type point struct{ x, y int32 }
type winMsg struct {
	hwnd    uintptr
	message uint32
	wParam  uintptr
	lParam  uintptr
	time    uint32
	pt      point
}
type rect struct{ left, top, right, bottom int32 }

type browseInfo struct {
	hwndOwner      uintptr
	pidlRoot       uintptr
	pszDisplayName *uint16
	lpszTitle      *uint16
	ulFlags        uint32
	lpfn           uintptr
	lParam         uintptr
	iImage         int32
}

type logFont struct {
	height, width, escapement, orientation, weight int32
	italic, underline, strikeOut, charSet          byte
	outPrecision, clipPrecision, quality, pitchFam byte
	faceName                                       [32]uint16
}
type ncMetrics struct {
	cbSize                                 uint32
	borderWidth, scrollWidth, scrollHeight int32
	captionWidth, captionHeight            int32
	captionFont                            logFont
	smCaptionWidth, smCaptionHeight        int32
	smCaptionFont                          logFont
	menuWidth, menuHeight                  int32
	menuFont, statusFont, messageFont      logFont
	paddedBorderWidth                      int32
}

func w(s string) *uint16    { p, _ := syscall.UTF16PtrFromString(s); return p }
func ptr(p *uint16) uintptr { return uintptr(unsafe.Pointer(p)) }

func msgBox(owner uintptr, text string, flags uintptr) int {
	r, _, _ := pMessageBox.Call(owner, ptr(w(text)), ptr(w(appName+" Installer")), flags)
	return int(r)
}

func sendMsg(h uintptr, m uint32, wp, lp uintptr) uintptr {
	r, _, _ := pSendMessage.Call(h, uintptr(m), wp, lp)
	return r
}

func getText(h uintptr) string {
	n, _, _ := pGetWindowTextLen.Call(h)
	buf := make([]uint16, n+2)
	pGetWindowText.Call(h, uintptr(unsafe.Pointer(&buf[0])), n+1)
	return syscall.UTF16ToString(buf)
}
func setText(h uintptr, s string) { pSetWindowText.Call(h, ptr(w(s))) }
func enable(h uintptr, on bool) {
	v := uintptr(0)
	if on {
		v = 1
	}
	pEnableWindow.Call(h, v)
}

func copyToClipboard(owner uintptr, s string) {
	u := utf16.Encode([]rune(s + "\x00"))
	if r, _, _ := pOpenClipboard.Call(owner); r == 0 {
		return
	}
	defer pCloseClipboard.Call()
	pEmptyClipboard.Call()
	h, _, _ := pGlobalAlloc.Call(0x0002, uintptr(len(u)*2)) // GMEM_MOVEABLE
	if h == 0 {
		return
	}
	p, _, _ := pGlobalLock.Call(h)
	if p == 0 {
		return
	}
	copy(unsafe.Slice((*uint16)(*(*unsafe.Pointer)(unsafe.Pointer(&p))), len(u)), u)
	pGlobalUnlock.Call(h)
	pSetClipboardData.Call(13, h) // CF_UNICODETEXT
}

func browseFolder(owner uintptr) string {
	pCoInitializeEx.Call(0, 2)
	title := w("Choose the installation folder")
	name := make([]uint16, 260)
	bi := browseInfo{hwndOwner: owner, pszDisplayName: &name[0], lpszTitle: title, ulFlags: 0x1 | 0x10 | 0x40}
	pidl, _, _ := pSHBrowseForFolder.Call(uintptr(unsafe.Pointer(&bi)))
	if pidl == 0 {
		return ""
	}
	defer pCoTaskMemFree.Call(pidl)
	buf := make([]uint16, 520)
	if r, _, _ := pSHGetPathFromID.Call(pidl, uintptr(unsafe.Pointer(&buf[0]))); r == 0 {
		return ""
	}
	return syscall.UTF16ToString(buf)
}

// ------------------------------------------------------------- registry

const uninstallKey = `Software\Microsoft\Windows\CurrentVersion\Uninstall\CharlieMJLanguage`

func regSet(h uintptr, name string, v interface{}) {
	switch t := v.(type) {
	case string:
		u := utf16.Encode([]rune(t + "\x00"))
		pRegSetValueEx.Call(h, ptr(w(name)), 0, syscall.REG_SZ, uintptr(unsafe.Pointer(&u[0])), uintptr(len(u)*2))
	case uint32:
		pRegSetValueEx.Call(h, ptr(w(name)), 0, syscall.REG_DWORD, uintptr(unsafe.Pointer(&t)), 4)
	}
}

func regGet(root syscall.Handle, key, name string) string {
	var h uintptr
	if r, _, _ := pRegOpenKey.Call(uintptr(root), ptr(w(key)), 0, 0x20019 /*KEY_READ*/, uintptr(unsafe.Pointer(&h))); r != 0 {
		return ""
	}
	defer pRegCloseKey.Call(h)
	var typ, n uint32
	if r, _, _ := pRegQueryValue.Call(h, ptr(w(name)), 0, uintptr(unsafe.Pointer(&typ)), 0, uintptr(unsafe.Pointer(&n))); r != 0 || n == 0 {
		return ""
	}
	buf := make([]uint16, n/2+2)
	if r, _, _ := pRegQueryValue.Call(h, ptr(w(name)), 0, uintptr(unsafe.Pointer(&typ)), uintptr(unsafe.Pointer(&buf[0])), uintptr(unsafe.Pointer(&n))); r != 0 {
		return ""
	}
	return syscall.UTF16ToString(buf)
}

func registerUninstall(dir, version string) error {
	var h uintptr
	var disp uint32
	if r, _, _ := pRegCreateKey.Call(uintptr(syscall.HKEY_CURRENT_USER), ptr(w(uninstallKey)), 0, 0, 0,
		0xF003F /*KEY_ALL_ACCESS*/, 0, uintptr(unsafe.Pointer(&h)), uintptr(unsafe.Pointer(&disp))); r != 0 {
		return fmt.Errorf("registry error %d", r)
	}
	defer pRegCloseKey.Call(h)
	un := filepath.Join(dir, uninstallName)
	regSet(h, "DisplayName", appName)
	regSet(h, "DisplayVersion", version)
	regSet(h, "Publisher", "Charlie MJ")
	regSet(h, "InstallLocation", dir)
	regSet(h, "DisplayIcon", un)
	regSet(h, "UninstallString", `"`+un+`" --uninstall`)
	regSet(h, "NoModify", uint32(1))
	regSet(h, "NoRepair", uint32(1))
	return nil
}

func findChrome() string {
	for _, root := range []syscall.Handle{syscall.HKEY_LOCAL_MACHINE, syscall.HKEY_CURRENT_USER} {
		p := strings.Trim(regGet(root, `SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe`, ""), `"`)
		if p != "" && fileExists(p) {
			return p
		}
	}
	for _, env := range []string{"ProgramFiles", "ProgramFiles(x86)", "LocalAppData"} {
		if base := os.Getenv(env); base != "" {
			p := filepath.Join(base, "Google", "Chrome", "Application", "chrome.exe")
			if fileExists(p) {
				return p
			}
		}
	}
	return ""
}

func fileExists(p string) bool { st, err := os.Stat(p); return err == nil && !st.IsDir() }

// -------------------------------------------------------------- the UI

type app struct {
	hwnd      uintptr
	dpi       int
	font      uintptr
	path      uintptr
	profCombo uintptr
	check     uintptr
	install   uintptr
	closeBtn  uintptr
	note      uintptr
	browse    uintptr
	profLbl   uintptr
	controls  []uintptr

	userData string
	profiles []Profile
	chrome   string
	version  string

	done     bool   // files installed
	doneDir  string // install dir used
	doneProf string // profile dir chosen ("" = none)
}

var ui app

func (a *app) s(x int) uintptr { return uintptr(x * a.dpi / 96) }

func (a *app) add(class, text string, style uint32, id int, x, y, wd, ht int) uintptr {
	h, _, _ := pCreateWindowEx.Call(0, ptr(w(class)), ptr(w(text)), uintptr(style|wsChild|wsVisible),
		a.s(x), a.s(y), a.s(wd), a.s(ht), a.hwnd, uintptr(id), 0, 0)
	a.controls = append(a.controls, h)
	return h
}

func loadIcon(size int) uintptr {
	hi, _, _ := pGetModuleHandle.Call(0)
	h, _, _ := pLoadImage.Call(hi, uintptr(iconResID), 1 /*IMAGE_ICON*/, uintptr(size), uintptr(size), 0)
	return h
}

func makeFont() uintptr {
	var ncm ncMetrics
	ncm.cbSize = uint32(unsafe.Sizeof(ncm))
	if r, _, _ := pSystemParamInfo.Call(0x29 /*SPI_GETNONCLIENTMETRICS*/, uintptr(ncm.cbSize), uintptr(unsafe.Pointer(&ncm)), 0); r != 0 {
		if f, _, _ := pCreateFontIndirec.Call(uintptr(unsafe.Pointer(&ncm.messageFont))); f != 0 {
			return f
		}
	}
	f, _, _ := pGetStockObject.Call(17) // DEFAULT_GUI_FONT
	return f
}

const idleNote = "The extension is copied to the folder above. Chrome then opens the selected profile so you can load it once with \"Load unpacked\" - " +
	"Chrome does not allow an installer to silently add an extension that is not from the Chrome Web Store."

func runInstaller() {
	runtime.LockOSThread()
	name, version := PayloadInfo(payloadZip)
	ui.version = version
	ui.chrome = findChrome()
	ui.userData = ChromeUserDataDir()
	if ui.userData != "" {
		ui.profiles = DetectProfiles(ui.userData)
	}
	ui.dpi = 96
	if r, _, _ := pGetDpiForSystem.Call(); r != 0 {
		ui.dpi = int(r)
	}

	hInst, _, _ := pGetModuleHandle.Call(0)
	cls := w("CharlieMJInstaller")
	cur, _, _ := pLoadCursor.Call(0, 32512)
	wc := wndClassEx{
		cbSize: uint32(unsafe.Sizeof(wndClassEx{})), lpfnWndProc: syscall.NewCallback(wndProc),
		hInstance: hInst, hIcon: loadIcon(32), hIconSm: loadIcon(16), hCursor: cur,
		hbrBackground: 16 /* COLOR_BTNFACE+1 */, lpszClassName: cls,
	}
	pRegisterClassEx.Call(uintptr(unsafe.Pointer(&wc)))

	style := uintptr(wsCaption | wsSysMenu | wsMinimizeBox)
	rc := rect{0, 0, int32(ui.s(540)), int32(ui.s(372))}
	pAdjustWindowRect.Call(uintptr(unsafe.Pointer(&rc)), style, 0, 0)
	ww, hh := uintptr(rc.right-rc.left), uintptr(rc.bottom-rc.top)
	sw, _, _ := pGetSystemMetrics.Call(0)
	sh, _, _ := pGetSystemMetrics.Call(1)
	hwnd, _, _ := pCreateWindowEx.Call(0, ptr(cls), ptr(w(name+" Installer")), style,
		(sw-ww)/2, (sh-hh)/2, ww, hh, 0, 0, hInst, 0)
	if hwnd == 0 {
		msgBox(0, "Could not create the installer window.", mbIconError)
		return
	}
	ui.hwnd = hwnd
	ui.font = makeFont()
	buildControls(name)
	for _, c := range ui.controls {
		sendMsg(c, wmSetFont, ui.font, 1)
	}
	if ic := loadIcon(32); ic != 0 {
		sendMsg(hwnd, wmSetIcon, 1, ic)
		sendMsg(hwnd, wmSetIcon, 0, loadIcon(16))
	}
	pShowWindow.Call(hwnd, 5)
	pSetForegroundWin.Call(hwnd)

	var m winMsg
	for {
		r, _, _ := pGetMessage.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		if d, _, _ := pIsDialogMessage.Call(hwnd, uintptr(unsafe.Pointer(&m))); d != 0 {
			continue
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessage.Call(uintptr(unsafe.Pointer(&m)))
	}
}

func buildControls(name string) {
	a := &ui
	if ic := loadIcon(48); ic != 0 {
		h := a.add("STATIC", "", ssIcon, 0, 20, 14, 48, 48)
		sendMsg(h, stmSetIcon, ic, 0)
	}
	a.add("STATIC", name+" Installer", ssNoPrefix, 0, 80, 20, 430, 20)
	v := "Installs the extension on this computer"
	if a.version != "" {
		v = "Version " + a.version
	}
	a.add("STATIC", v, ssNoPrefix, idVersion, 80, 42, 430, 18)
	a.add("STATIC", "", ssEtchedHorz, 0, 20, 74, 500, 2)

	a.add("STATIC", "Installation folder:", ssNoPrefix, 0, 20, 88, 300, 16)
	a.path = a.add("EDIT", defaultDir, wsTabStop|wsBorder|esAutoHScroll, idPath, 20, 108, 400, 24)
	a.browse = a.add("BUTTON", "Browse...", wsTabStop, idBrowse, 430, 107, 90, 26)

	a.profLbl = a.add("STATIC", "Chrome profile:", ssNoPrefix, idProfLbl, 20, 146, 300, 16)
	a.profCombo = a.add("COMBOBOX", "", wsTabStop|cbsDropList|0x200000, idProfile, 20, 166, 500, 200)
	if len(a.profiles) == 0 {
		sendMsg(a.profCombo, cbAddStr, 0, ptr(w("(no Chrome profile detected)")))
		enable(a.profCombo, false)
	} else {
		for _, p := range a.profiles {
			sendMsg(a.profCombo, cbAddStr, 0, ptr(w(p.Label())))
		}
	}
	sendMsg(a.profCombo, cbSetCur, 0, 0)

	a.check = a.add("BUTTON", "Set up "+appName+" in the selected Chrome profile (opens Chrome)", wsTabStop|bsAutoCheck, idCheck, 20, 204, 500, 22)
	if a.chrome != "" && len(a.profiles) > 0 {
		sendMsg(a.check, bmSetCheck, 1, 0)
	} else {
		enable(a.check, false)
		enable(a.profCombo, false)
	}
	a.note = a.add("STATIC", idleNote, 0, idNote, 20, 238, 500, 84)

	a.install = a.add("BUTTON", "Install", wsTabStop|bsDefPush, idInstall, 330, 334, 90, 28)
	a.closeBtn = a.add("BUTTON", "Close", wsTabStop, idClose, 430, 334, 90, 28)
}

func wndProc(hwnd, msg, wp, lp uintptr) uintptr {
	switch msg {
	case wmCommand:
		id := int(wp & 0xFFFF)
		switch id {
		case idBrowse:
			if p := browseFolder(hwnd); p != "" {
				if !strings.EqualFold(filepath.Base(p), appName) {
					p = filepath.Join(p, appName)
				}
				setText(ui.path, p)
			}
		case idInstall:
			if ui.done {
				onVerify()
			} else {
				onInstall()
			}
		case idClose:
			pDestroyWindow.Call(hwnd)
		}
		return 0
	case wmClose:
		pDestroyWindow.Call(hwnd)
		return 0
	case wmDestroy:
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProc.Call(hwnd, msg, wp, lp)
	return r
}

func onInstall() {
	a := &ui
	dir := filepath.Clean(strings.TrimSpace(getText(a.path)))
	if err := ValidateInstallDir(dir); err != nil {
		msgBox(a.hwnd, err.Error(), mbIconWarning)
		return
	}
	wantChrome := sendMsg(a.check, bmGetCheck, 0, 0) == 1
	profile := ""
	if wantChrome {
		i := int(int32(sendMsg(a.profCombo, cbGetCur, 0, 0)))
		if i < 0 || i >= len(a.profiles) {
			msgBox(a.hwnd, "Please select a Chrome profile.", mbIconWarning)
			return
		}
		profile = a.profiles[i].Dir
		if _, err := os.Stat(filepath.Join(a.userData, profile)); err != nil {
			msgBox(a.hwnd, "The selected Chrome profile no longer exists. Please choose another one.", mbIconWarning)
			return
		}
	}

	for _, c := range []uintptr{a.install, a.closeBtn, a.path, a.browse, a.profCombo, a.check} {
		enable(c, false)
	}
	setText(a.note, "Installing, please wait...")
	err := InstallFiles(dir, payloadZip)
	if err == nil {
		if exe, e := os.Executable(); e == nil {
			if e := CopyFile(exe, filepath.Join(dir, uninstallName)); e != nil {
				msgBox(a.hwnd, "Installed, but the uninstaller could not be created:\n"+e.Error(), mbIconWarning)
			} else if e := registerUninstall(dir, a.version); e != nil {
				msgBox(a.hwnd, "Installed, but it could not be listed in Apps & features:\n"+e.Error(), mbIconWarning)
			}
		}
	}
	enable(a.closeBtn, true)
	if err != nil {
		msgBox(a.hwnd, "Installation failed:\n\n"+err.Error()+
			"\n\nIf the folder is protected, choose a folder you own (for example inside your user folder).", mbIconError)
		for _, c := range []uintptr{a.install, a.path, a.browse} {
			enable(c, true)
		}
		if a.chrome != "" && len(a.profiles) > 0 {
			enable(a.check, true)
			enable(a.profCombo, true)
		}
		setText(a.note, idleNote)
		return
	}

	a.done, a.doneDir, a.doneProf = true, dir, profile
	extDir := ExtensionDir(dir)
	if !wantChrome {
		setText(a.note, "Installed to:\n"+extDir+"\n\nTo use it in Chrome: open chrome://extensions, turn on Developer mode, click \"Load unpacked\" and choose that folder.")
		return
	}
	copyToClipboard(a.hwnd, extDir)
	setText(a.note, "Files installed. Chrome is opening your \""+profile+"\" profile.\n\n"+
		"1. On chrome://extensions turn on \"Developer mode\" (top right).\n"+
		"2. Click \"Load unpacked\" and paste the folder path (already copied):\n    "+extDir+"\n"+
		"3. Come back here and click \"Verify\".")
	setText(a.install, "Verify")
	enable(a.install, true)
	cmd := exec.Command(a.chrome, "--profile-directory="+profile, "chrome://extensions")
	if err := cmd.Start(); err != nil {
		msgBox(a.hwnd, "Could not start Chrome:\n"+err.Error()+"\n\nOpen chrome://extensions yourself and load the folder shown.", mbIconWarning)
	}
}

func onVerify() {
	a := &ui
	if a.doneProf == "" {
		msgBox(a.hwnd, "No Chrome profile was selected, so there is nothing to verify.", mbIconInfo)
		return
	}
	ok, id := VerifyInstalled(a.userData, a.doneProf, ExtensionDir(a.doneDir))
	if ok {
		msgBox(a.hwnd, appName+" is installed in Chrome profile \""+a.doneProf+"\".\nExtension ID: "+id, mbIconInfo)
		return
	}
	msgBox(a.hwnd, appName+" was not found in profile \""+a.doneProf+"\" yet.\n\n"+
		"Finish \"Load unpacked\" on chrome://extensions in that profile (Chrome saves its settings a few seconds later), then click Verify again.", mbIconWarning)
}

// ----------------------------------------------------------- uninstaller

func runUninstaller() {
	runtime.LockOSThread()
	exe, _ := os.Executable()
	dir := regGet(syscall.HKEY_CURRENT_USER, uninstallKey, "InstallLocation")
	if dir == "" {
		dir = filepath.Dir(exe)
	}
	if msgBox(0, "Remove "+appName+" from\n"+dir+" ?", mbYesNo|mbIconInfo) != idYes {
		return
	}
	if err := RemoveInstalledFiles(dir); err != nil {
		msgBox(0, "Could not remove the extension files (is Chrome using them?):\n"+err.Error()+"\n\nClose Chrome and run the uninstaller again.", mbIconError)
		return
	}
	pRegDeleteKey.Call(uintptr(syscall.HKEY_CURRENT_USER), ptr(w(uninstallKey)))
	msgBox(0, appName+" files were removed.\n\nTo remove the extension from Chrome, open chrome://extensions in the profile you used and click \"Remove\".", mbIconInfo)
	// Delete uninstall.exe and the (now empty) folder after this process exits.
	line := fmt.Sprintf(`cmd.exe /c ping 127.0.0.1 -n 3 >nul & del /f /q "%s" & rmdir "%s"`, exe, dir)
	c := exec.Command("cmd.exe")
	c.Dir = os.TempDir()
	c.SysProcAttr = &syscall.SysProcAttr{CmdLine: line, HideWindow: true, CreationFlags: 0x08000000}
	_ = c.Start()
}
