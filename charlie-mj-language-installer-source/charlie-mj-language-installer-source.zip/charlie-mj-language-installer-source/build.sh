#!/usr/bin/env sh
# Build charlie-mj-language-installer.exe (needs Go >= 1.21 and Python 3; works on Linux/macOS/Windows-bash)
set -e
cd "$(dirname "$0")"
python3 tools/make_payload.py
python3 tools/make_syso.py
go test ./...
mkdir -p dist
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags="-s -w -H=windowsgui" -o dist/charlie-mj-language-installer.exe .
# Release ZIP that contains ONLY the installer exe
python3 - <<'PY'
import zipfile
with zipfile.ZipFile("dist/charlie-mj-language-installer.zip","w",zipfile.ZIP_DEFLATED) as z:
    z.write("dist/charlie-mj-language-installer.exe","charlie-mj-language-installer.exe")
PY
echo "Built dist/charlie-mj-language-installer.zip"
