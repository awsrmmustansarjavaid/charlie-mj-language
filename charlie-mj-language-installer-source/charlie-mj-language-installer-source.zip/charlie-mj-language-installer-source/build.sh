#!/usr/bin/env bash
# Builds dist/charlie-mj-language.exe and dist/charlie-mj-language-installer.exe
# Requirements (Debian/Ubuntu/WSL):  sudo apt install nsis mingw-w64
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p dist
( cd app
  x86_64-w64-mingw32-windres launcher.rc -O coff -o launcher_res.o
  x86_64-w64-mingw32-gcc -municode -mwindows -Os -s -o ../dist/charlie-mj-language.exe \
      launcher.c launcher_res.o -luser32 -lshell32 -ladvapi32 -static
  rm -f launcher_res.o )
( cd installer && makensis -V2 CharlieMJLanguageInstaller.nsi )
ls -la dist
