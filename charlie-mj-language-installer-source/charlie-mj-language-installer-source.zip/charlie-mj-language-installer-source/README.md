# Charlie MJ Language - installer source

Builds `charlie-mj-language-installer.exe`, a single self-contained Windows
installer (Go + raw Win32, no runtime/DLL dependencies, no admin rights needed).

    extension/   the Charlie MJ Language Chrome extension, unmodified
    core.go      profile detection, extraction, read-only verification (unit tested)
    gui_windows.go  installer / uninstaller window (Win32)
    main.go      entry point; embeds payload/extension.zip
    tools/       make_payload.py (zip the extension), make_syso.py (icon + manifest)
    build.sh / build.bat   one-step build -> dist/charlie-mj-language-installer.zip

## Build
Install Go and Python 3, then run `./build.sh` (or `build.bat` on Windows).
To ship a new extension version, replace `extension/` and rebuild.

## What the installer does
1. Default folder `C:\Charlie MJ Language\` (Browse... to change; never forced into Program Files/%APPDATA%).
2. Detects Chrome and its profiles from `%LOCALAPPDATA%\Google\Chrome\User Data\Local State`.
3. Extracts the extension to `<folder>\extension\`, writes `<folder>\uninstall.exe`
   and an "Apps & features" entry (per-user, HKCU).
4. Optionally opens Chrome on the chosen profile at `chrome://extensions`, copies the
   extension path to the clipboard, and you do "Load unpacked" once.
5. "Verify" reads (read-only) that profile's Preferences to confirm the extension is registered.

## What it deliberately does NOT do
It never edits Chrome's Preferences / Secure Preferences / LevelDB. Modern Chrome
rejects such edits and ignores `--load-extension`, and silent off-store installs are only
possible with enterprise policy (machine-wide, not per-profile) or the Chrome Web Store.
If you publish to the Web Store, the installer can instead just open the store page.

Uninstall: Windows Settings > Apps, or run `<folder>\uninstall.exe`; then click Remove
on `chrome://extensions` in the profile you used.
