#!/usr/bin/env python3
"""Zip ./extension (unchanged) into payload/extension.zip for go:embed."""
import os, sys, zipfile
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = os.path.join(root, "extension")
dst = os.path.join(root, "payload", "extension.zip")
if not os.path.isfile(os.path.join(src, "manifest.json")):
    sys.exit("extension/manifest.json not found")
os.makedirs(os.path.dirname(dst), exist_ok=True)
n = 0
with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for d, dirs, files in os.walk(src):
        dirs.sort()
        for f in sorted(files):
            p = os.path.join(d, f)
            z.write(p, os.path.relpath(p, src).replace(os.sep, "/"))
            n += 1
print(f"payload: {n} files -> {dst} ({os.path.getsize(dst)/1e6:.1f} MB)")
