#!/usr/bin/env python3
"""Generate rsrc_windows_amd64.syso (exe icon + application manifest) with
only the Python standard library, so no extra Windows tooling is needed.
Go links any *_windows_amd64.syso automatically."""
import os, struct

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
icons_dir = os.path.join(root, "extension", "icons")
out = os.path.join(root, "rsrc_windows_amd64.syso")

MANIFEST = b"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
  <assemblyIdentity type="win32" name="CharlieMJ.Language.Installer" version="1.0.0.0"/>
  <description>Charlie MJ Language Installer</description>
  <trustInfo xmlns="urn:schemas-microsoft-com:asm.v3">
    <security><requestedPrivileges>
      <requestedExecutionLevel level="asInvoker" uiAccess="false"/>
    </requestedPrivileges></security>
  </trustInfo>
  <dependency><dependentAssembly>
    <assemblyIdentity type="win32" name="Microsoft.Windows.Common-Controls" version="6.0.0.0"
      processorArchitecture="*" publicKeyToken="6595b64144ccf1df" language="*"/>
  </dependentAssembly></dependency>
  <compatibility xmlns="urn:schemas-microsoft-com:compatibility.v1"><application>
    <supportedOS Id="{8e0f7a12-bfb3-4fe8-b9a5-48fd50a15a9a}"/>
  </application></compatibility>
  <application xmlns="urn:schemas-microsoft-com:asm.v3"><windowsSettings>
    <dpiAware xmlns="http://schemas.microsoft.com/SMI/2005/WindowsSettings">true</dpiAware>
  </windowsSettings></application>
</assembly>
"""

# --- icons: PNG-compressed icon images (supported since Windows Vista)
sizes = [16, 32, 48, 128]
pngs = [(s, open(os.path.join(icons_dir, f"icon{s}.png"), "rb").read()) for s in sizes]
grp = struct.pack("<HHH", 0, 1, len(pngs))
for i, (s, data) in enumerate(pngs, start=1):
    grp += struct.pack("<BBBBHHIH", s, s, 0, 0, 1, 32, len(data), i)

# resource tree: type -> id -> data
RT_ICON, RT_GROUP_ICON, RT_MANIFEST = 3, 14, 24
tree = {
    RT_ICON: {i: d for i, (_, d) in enumerate(pngs, start=1)},
    RT_GROUP_ICON: {1: grp},
    RT_MANIFEST: {1: MANIFEST},
}

def dir_hdr(n):  # IMAGE_RESOURCE_DIRECTORY
    return struct.pack("<IIHHHH", 0, 0, 0, 0, 0, n)

# pass 1: sizes/offsets
types = sorted(tree)
off = 16 + 8 * len(types)
type_dir_off = {}
for t in types:
    type_dir_off[t] = off
    off += 16 + 8 * len(tree[t])
name_dir_off = {}
for t in types:
    for i in sorted(tree[t]):
        name_dir_off[(t, i)] = off
        off += 16 + 8
entry_off = {}
for t in types:
    for i in sorted(tree[t]):
        entry_off[(t, i)] = off
        off += 16
data_off = {}
for t in types:
    for i in sorted(tree[t]):
        data_off[(t, i)] = off
        off += (len(tree[t][i]) + 3) & ~3

buf = bytearray(off)
relocs = []
pos = 0
def put(b):
    global pos
    buf[pos:pos + len(b)] = b
    pos += len(b)

put(dir_hdr(len(types)))
for t in types:
    put(struct.pack("<II", t, 0x80000000 | type_dir_off[t]))
for t in types:
    assert pos == type_dir_off[t]
    put(dir_hdr(len(tree[t])))
    for i in sorted(tree[t]):
        put(struct.pack("<II", i, 0x80000000 | name_dir_off[(t, i)]))
for t in types:
    for i in sorted(tree[t]):
        assert pos == name_dir_off[(t, i)]
        put(dir_hdr(1))
        put(struct.pack("<II", 0x0409, entry_off[(t, i)]))
for t in types:
    for i in sorted(tree[t]):
        assert pos == entry_off[(t, i)]
        relocs.append(pos)  # OffsetToData is an RVA -> needs ADDR32NB reloc
        put(struct.pack("<IIII", data_off[(t, i)], len(tree[t][i]), 0, 0))
for t in types:
    for i in sorted(tree[t]):
        assert pos == data_off[(t, i)]
        put(tree[t][i])
        pos = (pos + 3) & ~3

raw = bytes(buf)
# --- COFF object
hdr_size, sec_size = 20, 40
raw_ptr = hdr_size + sec_size
reloc_ptr = raw_ptr + len(raw)
sym_ptr = reloc_ptr + 10 * len(relocs)
file_hdr = struct.pack("<HHIIIHH", 0x8664, 1, 0, sym_ptr, 1, 0, 0)
section = struct.pack("<8sIIIIIIHHI", b".rsrc", 0, 0, len(raw), raw_ptr, reloc_ptr, 0,
                      len(relocs), 0, 0xC0000040)
reloc_tbl = b"".join(struct.pack("<IIH", r, 0, 3) for r in relocs)  # sym 0, IMAGE_REL_AMD64_ADDR32NB
symbol = struct.pack("<8sIhHBB", b".rsrc", 0, 1, 0, 3, 0)
with open(out, "wb") as f:
    f.write(file_hdr + section + raw + reloc_tbl + symbol + struct.pack("<I", 4))
print(f"wrote {out} ({os.path.getsize(out)} bytes, {len(relocs)} resources)")
