package main

// core.go - platform independent installer logic (no Win32 calls here, so it
// can be unit tested on any OS).

import (
	"archive/zip"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

const (
	appName       = "Charlie MJ Language"
	defaultDir    = `C:\Charlie MJ Language`
	extSubdir     = "extension"
	uninstallName = "uninstall.exe"
)

// Profile is one Chrome profile found in the Chrome "User Data" directory.
type Profile struct {
	Dir  string // folder name, e.g. "Default" or "Profile 1"
	Name string // display name shown in Chrome, e.g. "Person 1"
}

func (p Profile) Label() string {
	if p.Name == "" || p.Name == p.Dir {
		return p.Dir
	}
	return p.Dir + "  (" + p.Name + ")"
}

// ---------------------------------------------------------------- Chrome

// ChromeUserDataDir returns Chrome's "User Data" directory, or "" if absent.
func ChromeUserDataDir() string {
	if v := os.Getenv("CMJ_CHROME_USER_DATA"); v != "" { // test / override hook
		return v
	}
	la := os.Getenv("LOCALAPPDATA")
	if la == "" {
		return ""
	}
	p := filepath.Join(la, "Google", "Chrome", "User Data")
	if st, err := os.Stat(p); err == nil && st.IsDir() {
		return p
	}
	return ""
}

// DetectProfiles lists the profiles of the Chrome installation at userData.
func DetectProfiles(userData string) []Profile {
	var out []Profile
	seen := map[string]bool{}
	add := func(dir, name string) {
		if dir == "" || seen[dir] {
			return
		}
		if st, err := os.Stat(filepath.Join(userData, dir)); err != nil || !st.IsDir() {
			return
		}
		seen[dir] = true
		out = append(out, Profile{Dir: dir, Name: name})
	}

	if raw, err := os.ReadFile(filepath.Join(userData, "Local State")); err == nil {
		var ls struct {
			Profile struct {
				InfoCache map[string]struct {
					Name string `json:"name"`
				} `json:"info_cache"`
			} `json:"profile"`
		}
		if json.Unmarshal(bytes.TrimPrefix(raw, []byte("\xef\xbb\xbf")), &ls) == nil {
			for dir, info := range ls.Profile.InfoCache {
				add(dir, info.Name)
			}
		}
	}
	if len(out) == 0 { // fall back to scanning folders
		if ents, err := os.ReadDir(userData); err == nil {
			for _, e := range ents {
				n := e.Name()
				if e.IsDir() && (n == "Default" || strings.HasPrefix(n, "Profile ")) {
					add(n, "")
				}
			}
		}
	}
	sort.Slice(out, func(i, j int) bool { return profileRank(out[i].Dir) < profileRank(out[j].Dir) })
	return out
}

func profileRank(dir string) string {
	if dir == "Default" {
		return "0"
	}
	if strings.HasPrefix(dir, "Profile ") {
		if n, err := strconv.Atoi(strings.TrimPrefix(dir, "Profile ")); err == nil {
			return fmt.Sprintf("1%08d", n)
		}
	}
	return "2" + dir
}

func normPath(p string) string {
	p = strings.ReplaceAll(p, "/", `\`)
	p = strings.TrimRight(p, `\`)
	return strings.ToLower(p)
}

// VerifyInstalled does a READ-ONLY check of the selected profile's
// Preferences / Secure Preferences and reports whether an extension whose
// path is extDir is registered there. It never writes to the profile.
func VerifyInstalled(userData, profileDir, extDir string) (bool, string) {
	want := normPath(extDir)
	for _, f := range []string{"Secure Preferences", "Preferences"} {
		raw, err := os.ReadFile(filepath.Join(userData, profileDir, f))
		if err != nil {
			continue
		}
		var prefs struct {
			Extensions struct {
				Settings map[string]struct {
					Path string `json:"path"`
				} `json:"settings"`
			} `json:"extensions"`
		}
		if json.Unmarshal(bytes.TrimPrefix(raw, []byte("\xef\xbb\xbf")), &prefs) != nil {
			continue
		}
		for id, s := range prefs.Extensions.Settings {
			if s.Path != "" && normPath(s.Path) == want {
				return true, id
			}
		}
	}
	return false, ""
}

// ---------------------------------------------------------------- paths

var absWinPath = regexp.MustCompile(`^([A-Za-z]:[\\/]|\\\\[^\\/]+[\\/][^\\/]+)`)

// ValidateInstallDir checks a user supplied installation folder.
func ValidateInstallDir(dir string) error {
	dir = strings.TrimSpace(dir)
	if dir == "" {
		return errors.New("Please choose an installation folder.")
	}
	if !absWinPath.MatchString(dir) {
		return errors.New("Please enter a full path such as C:\\Charlie MJ Language")
	}
	rest := dir
	if len(rest) >= 2 && rest[1] == ':' {
		rest = rest[2:]
	}
	if strings.ContainsAny(rest, `<>"|?*`) {
		return errors.New(`The folder name cannot contain  < > " | ? *`)
	}
	if len(strings.Trim(rest, `\/`)) == 0 {
		return errors.New("Please choose a folder, not the root of a drive.")
	}
	return nil
}

// ------------------------------------------------------------- payload

// PayloadInfo reads name and version from the embedded extension manifest.
func PayloadInfo(zipBytes []byte) (name, version string) {
	zr, err := zip.NewReader(bytes.NewReader(zipBytes), int64(len(zipBytes)))
	if err != nil {
		return appName, ""
	}
	for _, f := range zr.File {
		if f.Name == "manifest.json" {
			rc, err := f.Open()
			if err != nil {
				break
			}
			defer rc.Close()
			var m struct{ Name, Version string }
			if json.NewDecoder(rc).Decode(&m) == nil {
				return m.Name, m.Version
			}
		}
	}
	return appName, ""
}

// ExtensionDir is where the extension files live inside the install folder.
func ExtensionDir(installDir string) string { return filepath.Join(installDir, extSubdir) }

// InstallFiles extracts the embedded extension to <installDir>\extension,
// replacing any previous copy of it.
func InstallFiles(installDir string, zipBytes []byte) error {
	zr, err := zip.NewReader(bytes.NewReader(zipBytes), int64(len(zipBytes)))
	if err != nil {
		return fmt.Errorf("installer payload is damaged: %w", err)
	}
	if err := os.MkdirAll(installDir, 0o755); err != nil {
		return fmt.Errorf("cannot create %q: %w", installDir, err)
	}
	base := filepath.Clean(ExtensionDir(installDir))
	if err := os.RemoveAll(base); err != nil {
		return fmt.Errorf("cannot replace the previous installation (is a file in use?): %w", err)
	}
	if err := os.MkdirAll(base, 0o755); err != nil {
		return err
	}
	for _, f := range zr.File {
		target := filepath.Join(base, filepath.FromSlash(f.Name))
		if target != base && !strings.HasPrefix(target, base+string(os.PathSeparator)) {
			return fmt.Errorf("unsafe path in payload: %s", f.Name)
		}
		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(target, 0o755); err != nil {
				return err
			}
			continue
		}
		if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
			return err
		}
		if err := writeZipFile(f, target); err != nil {
			return err
		}
	}
	if _, err := os.Stat(filepath.Join(base, "manifest.json")); err != nil {
		return errors.New("installation incomplete: manifest.json missing")
	}
	return nil
}

func writeZipFile(f *zip.File, target string) error {
	rc, err := f.Open()
	if err != nil {
		return err
	}
	defer rc.Close()
	out, err := os.OpenFile(target, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o644)
	if err != nil {
		return err
	}
	if _, err := io.Copy(out, rc); err != nil {
		out.Close()
		return err
	}
	return out.Close()
}

// CopyFile copies src to dst.
func CopyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.OpenFile(dst, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o755)
	if err != nil {
		return err
	}
	if _, err := io.Copy(out, in); err != nil {
		out.Close()
		return err
	}
	return out.Close()
}

// RemoveInstalledFiles deletes only what the installer created: the
// extension folder (if it really is ours). uninstall.exe and the install
// folder itself are removed afterwards by the platform layer.
func RemoveInstalledFiles(installDir string) error {
	ext := ExtensionDir(installDir)
	if _, err := os.Stat(filepath.Join(ext, "manifest.json")); err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	return os.RemoveAll(ext)
}
