/* Charlie MJ Language - launcher
 * Opens Google Chrome in the profile chosen during installation.
 *   charlie-mj-language.exe            -> opens YouTube in the selected Chrome profile
 *   charlie-mj-language.exe --setup    -> copies the extension folder path to the clipboard,
 *                                         opens it in Explorer and opens chrome://extensions
 */
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <shellapi.h>
#include <wchar.h>

static int file_exists(const wchar_t *p) { return GetFileAttributesW(p) != INVALID_FILE_ATTRIBUTES; }

static int find_chrome(wchar_t *out, DWORD n)
{
    const wchar_t *key = L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\chrome.exe";
    HKEY roots[2] = { HKEY_CURRENT_USER, HKEY_LOCAL_MACHINE };
    for (int i = 0; i < 2; i++) {
        HKEY k;
        if (RegOpenKeyExW(roots[i], key, 0, KEY_READ, &k) == ERROR_SUCCESS) {
            DWORD sz = (n - 1) * sizeof(wchar_t), type = 0;
            LONG r = RegQueryValueExW(k, NULL, NULL, &type, (LPBYTE)out, &sz);
            RegCloseKey(k);
            if (r == ERROR_SUCCESS) {
                out[n - 1] = 0;
                if (file_exists(out)) return 1;
            }
        }
    }
    const wchar_t *envs[3] = { L"ProgramFiles", L"ProgramFiles(x86)", L"LOCALAPPDATA" };
    for (int i = 0; i < 3; i++) {
        wchar_t base[MAX_PATH];
        if (GetEnvironmentVariableW(envs[i], base, MAX_PATH) > 0) {
            _snwprintf(out, n, L"%ls\\Google\\Chrome\\Application\\chrome.exe", base);
            out[n - 1] = 0;
            if (file_exists(out)) return 1;
        }
    }
    return 0;
}

static void copy_to_clipboard(const wchar_t *text)
{
    size_t bytes = (wcslen(text) + 1) * sizeof(wchar_t);
    HGLOBAL h = GlobalAlloc(GMEM_MOVEABLE, bytes);
    if (!h) return;
    void *p = GlobalLock(h);
    if (!p) { GlobalFree(h); return; }
    memcpy(p, text, bytes);
    GlobalUnlock(h);
    if (OpenClipboard(NULL)) {
        EmptyClipboard();
        if (!SetClipboardData(CF_UNICODETEXT, h)) GlobalFree(h);
        CloseClipboard();
    } else {
        GlobalFree(h);
    }
}

int WINAPI wWinMain(HINSTANCE hi, HINSTANCE hp, LPWSTR cmd, int show)
{
    (void)hi; (void)hp; (void)show;
    wchar_t exe[MAX_PATH], base[MAX_PATH], cfg[MAX_PATH], extdir[MAX_PATH];
    GetModuleFileNameW(NULL, exe, MAX_PATH);
    wcscpy(base, exe);
    wchar_t *slash = wcsrchr(base, L'\\');
    if (slash) *slash = 0;
    _snwprintf(cfg, MAX_PATH, L"%ls\\config.ini", base);
    _snwprintf(extdir, MAX_PATH, L"%ls\\extension", base);

    wchar_t profile[128];
    GetPrivateProfileStringW(L"Settings", L"Profile", L"Default", profile, 128, cfg);
    if (profile[0] == 0 || wcschr(profile, L'"')) wcscpy(profile, L"Default");

    wchar_t chrome[MAX_PATH];
    if (!find_chrome(chrome, MAX_PATH)) {
        MessageBoxW(NULL, L"Google Chrome was not found on this PC.\nPlease install Google Chrome and try again.",
                    L"Charlie MJ Language", MB_ICONERROR | MB_OK);
        return 1;
    }

    int setup = (cmd && wcsstr(cmd, L"--setup") != NULL);
    const wchar_t *url = L"https://www.youtube.com/";

    if (setup) {
        if (!file_exists(extdir)) {
            MessageBoxW(NULL, L"The extension folder was not found.\nPlease run charlie-mj-language-installer.exe again.",
                        L"Charlie MJ Language", MB_ICONERROR | MB_OK);
            return 1;
        }
        copy_to_clipboard(extdir);
        ShellExecuteW(NULL, L"open", extdir, NULL, NULL, SW_SHOWNORMAL);
        url = L"chrome://extensions/";
    }

    wchar_t line[1024];
    _snwprintf(line, 1024, L"\"%ls\" --profile-directory=\"%ls\" \"%ls\"", chrome, profile, url);
    line[1023] = 0;
    STARTUPINFOW si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof si); si.cb = sizeof si;
    ZeroMemory(&pi, sizeof pi);
    if (!CreateProcessW(NULL, line, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
        MessageBoxW(NULL, L"Could not start Google Chrome.", L"Charlie MJ Language", MB_ICONERROR | MB_OK);
        return 1;
    }
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
    return 0;
}
