package main

import (
	_ "embed"
	"os"
	"path/filepath"
	"strings"
)

// payload/extension.zip is produced by tools/make_payload.py from ./extension
//
//go:embed payload/extension.zip
var payloadZip []byte

func main() {
	exe, _ := os.Executable()
	uninstall := strings.Contains(strings.ToLower(filepath.Base(exe)), "uninstall")
	for _, a := range os.Args[1:] {
		if a == "--uninstall" || a == "/uninstall" {
			uninstall = true
		}
	}
	if uninstall {
		runUninstaller()
		return
	}
	runInstaller()
}
