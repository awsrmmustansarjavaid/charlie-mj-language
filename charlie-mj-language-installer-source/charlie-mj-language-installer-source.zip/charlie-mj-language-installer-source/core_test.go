package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestPayloadAndInstall(t *testing.T) {
	name, ver := PayloadInfo(payloadZip)
	if name != "Charlie MJ Language" || ver == "" {
		t.Fatalf("payload info: %q %q", name, ver)
	}
	dir := filepath.Join(t.TempDir(), "Charlie MJ Language")
	if err := InstallFiles(dir, payloadZip); err != nil {
		t.Fatal(err)
	}
	for _, f := range []string{"manifest.json", "src/background/service-worker.js", "icons/icon128.png", "assets/charlie-mj-language-main-thumbnail.png"} {
		if _, err := os.Stat(filepath.Join(ExtensionDir(dir), filepath.FromSlash(f))); err != nil {
			t.Errorf("missing %s", f)
		}
	}
	// reinstall over existing copy
	if err := InstallFiles(dir, payloadZip); err != nil {
		t.Fatal(err)
	}
	if err := RemoveInstalledFiles(dir); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(ExtensionDir(dir)); !os.IsNotExist(err) {
		t.Error("extension dir should be gone")
	}
}

func TestProfiles(t *testing.T) {
	ud := t.TempDir()
	for _, d := range []string{"Default", "Profile 2", "Profile 10", "Profile 1", "System Profile"} {
		os.MkdirAll(filepath.Join(ud, d), 0o755)
	}
	os.WriteFile(filepath.Join(ud, "Local State"), []byte(`{"profile":{"info_cache":{
	 "Profile 10":{"name":"Ten"},"Default":{"name":"Charlie"},"Profile 1":{"name":"Work \u00e9"},"Profile 9":{"name":"Deleted"}}}}`), 0o644)
	ps := DetectProfiles(ud)
	want := []string{"Default", "Profile 1", "Profile 10"}
	if len(ps) != len(want) {
		t.Fatalf("got %+v", ps)
	}
	for i, w := range want {
		if ps[i].Dir != w {
			t.Errorf("order: %+v", ps)
		}
	}
	if ps[1].Name != "Work é" {
		t.Errorf("name %q", ps[1].Name)
	}
	// fallback to folder scan
	os.Remove(filepath.Join(ud, "Local State"))
	if ps := DetectProfiles(ud); len(ps) != 4 || ps[0].Dir != "Default" || ps[3].Dir != "Profile 10" {
		t.Errorf("fallback %+v", ps)
	}
}

func TestVerify(t *testing.T) {
	ud := t.TempDir()
	os.MkdirAll(filepath.Join(ud, "Default"), 0o755)
	os.WriteFile(filepath.Join(ud, "Default", "Secure Preferences"),
		[]byte(`{"extensions":{"settings":{"abc":{"path":"C:\\Charlie MJ Language\\extension"},"zzz":{"path":"other"}}}}`), 0o644)
	if ok, id := VerifyInstalled(ud, "Default", `c:\charlie mj language\extension\`); !ok || id != "abc" {
		t.Errorf("verify: %v %q", ok, id)
	}
	if ok, _ := VerifyInstalled(ud, "Default", `D:\x\extension`); ok {
		t.Error("false positive")
	}
	if ok, _ := VerifyInstalled(ud, "Profile 3", `C:\Charlie MJ Language\extension`); ok {
		t.Error("missing profile")
	}
}

func TestValidate(t *testing.T) {
	good := []string{`C:\Charlie MJ Language`, `D:\Applications\Charlie MJ Language\`, `\\srv\share\x`}
	bad := []string{``, `relative\dir`, `C:\`, `C:\bad*name`, `C:`}
	for _, g := range good {
		if err := ValidateInstallDir(g); err != nil {
			t.Errorf("%q: %v", g, err)
		}
	}
	for _, b := range bad {
		if ValidateInstallDir(b) == nil {
			t.Errorf("%q should fail", b)
		}
	}
}
