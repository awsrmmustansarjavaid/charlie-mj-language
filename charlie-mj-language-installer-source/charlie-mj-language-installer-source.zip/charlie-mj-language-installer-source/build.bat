@echo off
rem Build on Windows (needs Go and Python 3 on PATH)
cd /d "%~dp0"
python tools\make_payload.py || exit /b 1
python tools\make_syso.py || exit /b 1
go test ./... || exit /b 1
if not exist dist mkdir dist
set GOOS=windows
set GOARCH=amd64
set CGO_ENABLED=0
go build -trimpath -ldflags="-s -w -H=windowsgui" -o dist\charlie-mj-language-installer.exe . || exit /b 1
python -c "import zipfile;z=zipfile.ZipFile('dist/charlie-mj-language-installer.zip','w',zipfile.ZIP_DEFLATED);z.write('dist/charlie-mj-language-installer.exe','charlie-mj-language-installer.exe')"
echo Built dist\charlie-mj-language-installer.zip
